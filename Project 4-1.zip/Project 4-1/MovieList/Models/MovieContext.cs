﻿using Microsoft.EntityFrameworkCore;

namespace MovieList.Models
{
    public class MovieContext : DbContext
    {
        public MovieContext(DbContextOptions<MovieContext> options)
            : base(options)
        { }

        public DbSet<Movie> Movies { get; set; }
        public DbSet<Genre> Genres { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Genre>().HasData(
                 new Genre { GenreId = "Family", Name = "Family" },
                 new Genre { GenreId = "Work", Name = "Work" },
                 new Genre { GenreId = "Friend", Name = "Friend" }
             );

            modelBuilder.Entity<Movie>().HasData(
                new Movie
                {
                    MovieId = 1,
                    Name = "Casablanca",
                    LName = "Casablanca",
                    Phone = "502-123-4567",
                    Email = "mans@gmail.com",
                    GenreId = "Family"
                },
                new Movie
                {
                    MovieId = 2,
                    Name = "Wonder Woman",
                    LName = "Strength",
                    Phone = "502-123-4567",
                    Email = "wstrength@gmail.com",
                    GenreId = "Work"
                },
                new Movie
                {
                    MovieId = 3,
                    Name = "John",
                    LName = "Cena",
                    Phone = "502-123-4567",
                    Email = "ucantseeme@gmail.com",
                    GenreId = "Friend"
                }
            ); ;
        }
    }
}

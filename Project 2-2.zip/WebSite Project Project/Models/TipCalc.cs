﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebSite_Project_Project.Models
{
    public class TipCalculator
    {
        [Required(ErrorMessage = "Please enter a digit between 0 and 10000.")]
        [Range(0, 10000, ErrorMessage =
              "Monthly investment amount must be between 0 and 10000.")]
        public decimal? CostofMeal{ get; set; }
                
        public decimal? discount15()
        {
            decimal? futureValue = 0;
            decimal? tip15 = (decimal?).15;
            futureValue = (CostofMeal * tip15);

            return futureValue;
        }
        public decimal? discount20()
        {
            decimal? futureValue = 0;
            decimal? tip20 = (decimal?).20;
            futureValue = (CostofMeal * tip20);

            return futureValue;
        }
        public decimal? discount25()
        {
            decimal? futureValue = 0;
            decimal? Tip25 = (decimal?).25;
            futureValue = (CostofMeal * Tip25);

            return futureValue;
        }

       
    }
}
